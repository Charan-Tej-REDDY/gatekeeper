package in.charan.gatekeeper.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartGatewayServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
